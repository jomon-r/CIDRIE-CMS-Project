import React from 'react'

function Report() {
  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '90vh'
    }}
  >
    <h1>About</h1></div>
  )
}

export default Report