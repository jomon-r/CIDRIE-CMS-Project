import React from 'react'

function Complaints() {
  return (
    <div><h1>mplaints</h1></div>
  )
}

export default Complaints