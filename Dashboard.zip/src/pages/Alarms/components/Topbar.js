import React from 'react'

const Topbar = () => {
    return (
        <div style={{
            background:'Grey',
            position: 'absolute',
            top: '45px',
            width: '100%',
            height: '45px',
            color: 'white',
            textAlign: 'center'
    
        }}></div>
    )
} 
export default Topbar