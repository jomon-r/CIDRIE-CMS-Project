import React from 'react'

function SOS() {
  return (
    <div>SOS</div>
  )
}

export default SOS