import React from 'react'

function Master() {
  return (
    <div>Master</div>
  )
}

export default Master