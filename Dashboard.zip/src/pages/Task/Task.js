import React from 'react'

function Task() {
  return (
    <div>Task</div>
  )
}

export default Task